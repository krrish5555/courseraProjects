// ProjectsSection.js
import React from "react";
import { Box, Heading } from "@chakra-ui/react";
import Card from "./Card";
import FullScreenSection from "./FullScreenSection";

const projects = [
  {
    title: "React E-Commerce Platform",
    description:
      "Create a comprehensive e-commerce platform using React, incorporating features like product listings, shopping cart functionality, user authentication, and payment processing. This project aims to provide users with a seamless and enjoyable shopping experience by implementing robust e-commerce features and ensuring secure transactions.",
    additionalDetails: `
      Build a robust e-commerce platform with React, allowing users to browse through a wide range of products, add items to their cart, and securely complete the purchase. Implement user authentication to provide personalized experiences, and integrate payment processing for a seamless shopping experience.

      Additional Features:
      Product Reviews: Enable users to leave reviews and ratings for products.
      Order History: Provide users with a detailed history of their past orders.
      Wishlist: Allow users to create and manage wishlists for future purchases.
      Responsive Design: Ensure a smooth and responsive experience across devices.
      Discounts and Promotions: Implement discount codes and promotional offers.
      Product Recommendations: Use algorithms to suggest relevant products to users.
      Multi-Language Support: Support multiple languages for a global user base.
      Admin Dashboard: Create a comprehensive dashboard for administrators to manage products and orders.
      Secure Transactions: Implement encryption and security measures for safe transactions.
      Real-time Updates: Provide real-time updates on order processing and shipping.

      Transform your React skills into a powerful e-commerce solution, offering users a seamless and enjoyable shopping experience.
    `,
    getImageSrc: () => require("../images/photo1.jpg"),
  },
  {
    title: "React Social Media App",
    description:
      "Develop a social media application using React, enabling users to create profiles, share posts, like and comment on content, and connect with friends. This project focuses on creating a dynamic and engaging social media platform where users can connect, share content, and build a social network.",
    additionalDetails: `
      Create a dynamic social media app with React, where users can create profiles, share posts, engage with content through likes and comments, and build connections with friends. Implement features for real-time updates and notifications to enhance the overall user experience.

      Additional Features:
      Friend Requests: Allow users to send and accept friend requests.
      Privacy Settings: Enable users to customize the visibility of their posts.
      Group Chats: Implement group chat functionality for collaborative discussions.
      Trending Hashtags: Display trending hashtags for users to explore popular topics.
      Multimedia Sharing: Support sharing images, videos, and other multimedia content.
      Explore Page: Create a dedicated page for discovering new content and users.
      User Analytics: Provide users with insights into their profile engagement and interactions.
      Dark Mode: Implement a dark mode option for a personalized user experience.
      User Verification: Introduce a verification system for authenticating user accounts.
      Accessibility Features: Ensure the app is accessible to users with diverse needs.

      Elevate your React expertise by crafting a social media platform that fosters connections and content sharing.
    `,
    getImageSrc: () => require("../images/photo2.jpg"),
  },
  {
    title: "React Task Management System",
    description:
      "Build a task management system with React, allowing users to create, organize, and track tasks, set deadlines, and collaborate with team members. This project focuses on enhancing productivity by providing users with a comprehensive tool for managing tasks and projects efficiently.",
    additionalDetails: `
      Develop an efficient task management system using React, empowering users to create, organize, and track tasks. Implement features such as setting deadlines, assigning tasks to team members, and providing collaboration tools for seamless teamwork.

      Additional Features:
      Priority Levels: Allow users to assign priority levels to tasks.
      Kanban Board: Implement a visual Kanban board for task organization.
      Team Notifications: Enable notifications for task updates and mentions.
      Time Tracking: Provide tools for users to track the time spent on tasks.
      Calendar Integration: Sync tasks with external calendars for better planning.
      Customizable Workflows: Allow users to customize task workflows based on their processes.
      File Attachments: Support attaching files and documents to tasks.
      Project Overview: Create a dashboard for an overview of project progress.
      Task Dependencies: Introduce dependencies between tasks for logical sequencing.
      Export and Reporting: Enable users to export task data and generate reports.

      Transform your React skills into a powerful tool for managing tasks and projects with efficiency and collaboration.
    `,
    getImageSrc: () => require("../images/photo3.jpg"),
  },
  {
    title: "React Fitness Tracker",
    description:
      "Create a fitness tracking application with React, enabling users to log their workouts, set fitness goals, and track progress over time. This project aims to promote a healthy lifestyle by providing users with tools to monitor and achieve their fitness objectives.",
    additionalDetails: `
      Design and implement a fitness tracker application using React, allowing users to log their workouts, set fitness goals, and track their progress over time. Incorporate features such as workout history, goal achievements, and personalized analytics to motivate users on their fitness journey.

      Additional Features:
      Exercise Database: Include a comprehensive database of exercises for tracking.
      Nutrition Tracking: Allow users to log their daily nutrition intake.
      Wearable Device Integration: Integrate with popular wearable devices for seamless data synchronization.
      Social Challenges: Create challenges for users to engage in friendly competition.
      Achievement Badges: Reward users with badges for reaching fitness milestones.
      Workout Plans: Provide pre-built workout plans for users with different fitness goals.
      Progress Photos: Allow users to upload and track progress photos.
      Community Forums: Foster a community by adding discussion forums for fitness tips.
      Personalized Recommendations: Provide workout and nutrition recommendations based on user data.
      Goal Reminders: Send reminders to users for upcoming fitness goals.

      Empower users to achieve their fitness goals with a feature-rich React fitness tracker application.
    `,
    getImageSrc: () => require("../images/photo4.jpg"),
  },
];



const ProjectsSection = () => {
  return (
    <FullScreenSection
      backgroundColor="#14532d"
      isDarkBackground
      p={8}
      alignItems="flex-start"
      spacing={8}
    >
      <Heading as="h1" id="projects-section">
        Featured Projects
      </Heading>
      <Box
        display="grid"
        gridTemplateColumns="repeat(2,minmax(0,1fr))"
        gridGap={8}
      >
        {projects.map((project) => (
          <Card
            key={project.title}
            title={project.title}
            description={project.description}
            additionalDetails={project.additionalDetails}
            imageSrc={project.getImageSrc()}
          />
        ))}
      </Box>
    </FullScreenSection>
  );
};

export default ProjectsSection;
