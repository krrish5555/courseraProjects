// Card.js
import React, { useState } from "react";
import { Box, Heading, Text, Image, Button } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight, faEyeSlash } from "@fortawesome/free-solid-svg-icons"; // Import FontAwesome icons

const Card = ({ title, description, additionalDetails, imageSrc }) => {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <Box maxW="sm" borderWidth="1px" borderRadius="lg" overflow="hidden">
      <Image src={imageSrc} alt={title} />
      <Box p="6">
        <Heading fontSize="20px" mt="1" fontWeight="semibold" lineHeight="tight">
          {title}
        </Heading>
        <Text mt="2" color="white">
          {showDetails ? additionalDetails : description}
        </Text>
        {description !== additionalDetails && (
          <Button
            mt="4"
            colorScheme="purple"
            onClick={() => setShowDetails(!showDetails)}
            rightIcon={
              <FontAwesomeIcon icon={showDetails ? faEyeSlash : faArrowRight} />
            } // Use faArrowRight for the right arrow
          >
            {showDetails ? "See Less" : "See More"}
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default Card;
