import React, { useState } from 'react';
import './App.css';

const Calculator = () => {
  const [input, setInput] = useState('0');
  const [isResult, setIsResult] = useState(false);

  const handleButtonClick = (value) => {
    setInput((prevInput) => {
      if (value === 'C') {
        setIsResult(false);
        return '0';
      }
  
      if (prevInput.includes('Error')) {
        return value;
      }
  
      if (value === '<-' && prevInput !== 'C') {
        const newInput = prevInput.length > 1 ? prevInput.slice(0, -1) : '0';
        return newInput.includes('=') ? newInput.split('=')[0] : newInput;
      }
  
      if (/^\d$/.test(value)) {
        if (isResult) {
          setIsResult(false);
          return value;
        }
        return prevInput === '0' || prevInput.includes('=') ? value : prevInput + value;
      }
  
      if (value === '.') {
        if (isResult || prevInput.includes('=')) {
          setIsResult(false);
          return '0' + value;
        }
        if (!prevInput.match(/[-+*/]$/)) {
          return prevInput.includes('.') ? prevInput : prevInput + value;
        }
        return prevInput;
      }
  
      if (value === '%') {
        const inputToCalculate = prevInput.includes('=') ? prevInput.split('=')[1] : prevInput;
        if (inputToCalculate) {
          const percentageValue = (parseFloat(inputToCalculate) / 100).toString();
          return percentageValue.endsWith('.00') ? percentageValue.replace('.00', '') : percentageValue;
        }
        return prevInput;
      }
  
      if (value === 'x^2') {
        const inputToCalculate = prevInput.includes('=') ? prevInput.split('=')[1] : prevInput;
        if (inputToCalculate) {
          const squareValue = (parseFloat(inputToCalculate) ** 2).toString();
          return squareValue.endsWith('.00') ? squareValue.replace('.00', '') : squareValue;
        }
        return prevInput;
      }
  
      if (value.match(/[-+*/]/)) {
        setIsResult(false);
        return prevInput.match(/[-+*/]$/) ? prevInput.slice(0, -1) + value : prevInput + value;
      }
  
      return prevInput;
    });
  };
  

  const calculateResult = () => {
    try {
      const result = eval(input);
      setInput(result.toString());
      setIsResult(true);
    } catch (error) {
      setInput('Error');
    }
  };

  return (
    <div className="calculator-container">
      <div className="calculator">
        <div className="display">
          <input type="text" value={input} readOnly />
        </div>
        <div className="buttons">
          {['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.'].map((value) => (
            <button key={value} onClick={() => handleButtonClick(value)}>
              {value}
            </button>
          ))}
          <button onClick={() => calculateResult()} className="center">=</button>
          <button onClick={() => handleButtonClick('+')} className="center">+</button>
          <button onClick={() => handleButtonClick('<-')} className="operator">
            &lt;-
          </button>
          <button onClick={() => handleButtonClick('C')} className="operator">
            C
          </button>
          <button onClick={() => handleButtonClick('%')}>%</button>
          <button onClick={() => handleButtonClick('x^2')}>x^2</button>
        </div>
      </div>
    </div>
  );
};

export default Calculator;
